The enclosed files serve as a demonstration of the
document class `examz' and the `counterz' package.

1. Download ExampleWithSage.zip, extract it to your
desired directory, and open the folder ExampleWithSage

2. Open the file TestWithSage.tex and use (pdf)LaTeX
to typeset the document. Enter 1 at the terminal
prompt to randomize the document, and then enter 5
at the next prompt to generate five versions.

3. Run Sage on the file TestWithSage.sagetex.sage

3. Typeset the document a second time. Enter 2 at
the terminal prompt to not randomize the document.

4. Explore the file TestWithSage.pdf to see the output.

5. Explore the file TestWithSage.counters.tex to see how
the randomly generated counters are saved and recalled.

6. Explore the file examzsage.cls to see how the
document is formatted.

7. Explore the files in the folder Problems to see
how the problems are written.

Note: The command \sage may be used in problems and
solutions, but the environments sageblock and sagesilent
will not easily work inside of other environments. This
is the reason for the file sagesilent.tex .

Send comments, questions, and bug reports to
christopher.mcclain@mail.wvu.edu
