The enclosed files serve as a demonstration of the
document class `examz' and the `counterz' package.

1. Download Example.zip, extract it to your desired
directory, and open the folder Example.

2. Open the file Test.tex and use (pdf)LaTeX
to typeset the document. Enter 1 at the terminal
prompt to randomize the document, and then enter 5
at the next prompt to generate five versions.

3. Typeset the document a second time. Enter 2 at
the terminal prompt to not randomize the document.

4. Explore the file Test.pdf to see the output.

5. Explore the file Test.counters.tex to see how the
randomly generated counters are saved and recalled.

6. Explore the file Myexamz.cls to see how the
document is formatted.

7. Explore the files in the folder Problems to see
how the problems are written.

Send comments, questions, and bug reports to
christopher.mcclain@mail.wvu.edu
